// script.js

document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('header h1');
  const footer = document.querySelector('footer p');
  const button = document.getElementById('changeColorButton');

  // Cambiar el contenido del encabezado
  header.textContent = 'Bienvenido a Mi Página Web Dinámica usando el DOM';

  // Agregar un nuevo elemento a la barra de navegación
  const nav = document.getElementById('contenido');
  const newItem = document.createElement('a');
  newItem.textContent = 'Regístrate';
  newItem.className = 'item'; // 
  newItem.href = '#'; // 
  nav.appendChild(newItem);

  // Modificar el estilo del pie de página
  footer.style.color = 'blue';

  // Cambiar el color de la página
  button.addEventListener('click', () => {
      document.body.style.backgroundColor = 'chartreuse';
  });

  // Cambiar el color de fondo del encabezado al pasar el mouse
  header.addEventListener('mouseover', () => {
      header.style.backgroundColor = 'red';
  });

  header.addEventListener('mouseleave', () => {
      header.style.backgroundColor = 'yellow';
  });
});
